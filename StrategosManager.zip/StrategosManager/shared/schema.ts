import { pgTable, text, serial, timestamp, boolean, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Role enum for user types - adding esports-specific roles
export const roleEnum = pgEnum("role", ["admin", "manager", "coach", "player", "analyst", "substitute"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: roleEnum("role").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Enhanced teams table with esports features
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  // New esports-specific fields
  game: text("game"),  // Primary game the team plays
  division: text("division"), // Competitive division/tier
  achievements: jsonb("achievements"), // Array of team achievements
  stats: jsonb("stats"), // Team performance statistics
  ownerId: serial("owner_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  teamId: serial("team_id").references(() => teams.id),
  userId: serial("user_id").references(() => users.id),
  role: roleEnum("role").notNull(),
  // New fields for player/member details
  nickname: text("nickname"), // In-game name
  position: text("position"), // Primary position/role in team
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  active: boolean("active").default(true),
});

// New table for team practice schedules
export const practiceSchedules = pgTable("practice_schedules", {
  id: serial("id").primaryKey(),
  teamId: serial("team_id").references(() => teams.id),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  recurring: boolean("recurring").default(false),
  recurrencePattern: text("recurrence_pattern"), // e.g., "weekly", "daily"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const strategies = pgTable("strategies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  gameType: text("game_type").notNull(),
  content: jsonb("content").notNull(),
  team_id: serial("team_id").references(() => teams.id),
  createdById: serial("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Enhanced schema for team creation/updates
export const insertTeamSchema = createInsertSchema(teams)
  .pick({
    name: true,
    description: true,
    game: true,
    division: true,
    achievements: true,
    stats: true,
  })
  .extend({
    name: z.string().min(1, "Team name is required"),
    description: z.string().optional(),
    game: z.string().optional(),
    division: z.string().optional(),
    achievements: z.array(z.object({
      title: z.string(),
      date: z.string(),
      description: z.string().optional(),
    })).optional().default([]),
    stats: z.object({
      wins: z.number(),
      losses: z.number(),
      winRate: z.number(),
      lastUpdated: z.string(),
    }).optional().default({
      wins: 0,
      losses: 0,
      winRate: 0,
      lastUpdated: new Date().toISOString()
    }),
  });

// Schema for practice schedule creation
export const insertPracticeScheduleSchema = createInsertSchema(practiceSchedules)
  .pick({
    teamId: true,
    title: true,
    description: true,
    startTime: true,
    endTime: true,
    recurring: true,
    recurrencePattern: true,
  })
  .extend({
    title: z.string().min(1, "Title is required"),
    description: z.string().optional(),
    startTime: z.string().transform((str) => new Date(str)),
    endTime: z.string().transform((str) => new Date(str)),
    recurring: z.boolean().optional(),
    recurrencePattern: z.string().optional(),
  });

// User schema
export const insertUserSchema = createInsertSchema(users)
  .pick({
    email: true,
    password: true,
    name: true,
    role: true,
  })
  .extend({
    email: z.string().email("Please enter a valid email address"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    name: z.string().min(2, "Name must be at least 2 characters"),
    role: z.enum(["admin", "manager", "coach", "player", "analyst", "substitute"]),
  });

// Team member schema
export const insertTeamMemberSchema = createInsertSchema(teamMembers)
  .pick({
    teamId: true,
    userId: true,
    role: true,
    nickname: true,
    position: true,
    joinedAt: true,
    active: true,
  })
  .extend({
    email: z.string().email("Please enter a valid email address"),
    role: z.enum(["admin", "manager", "coach", "player", "analyst", "substitute"]),
    nickname: z.string().optional(),
    position: z.string().optional(),
    active: z.boolean().optional(),
  });

// Strategy schema
export const insertStrategySchema = createInsertSchema(strategies)
  .pick({
    title: true,
    description: true,
    gameType: true,
    content: true,
    team_id: true,
  })
  .extend({
    title: z.string().min(1, "Title is required").max(100, "Title is too long"),
    description: z.string().min(1, "Description is required").max(500, "Description is too long"),
    gameType: z.string().min(1, "Game type is required"),
    team_id: z.number().int().positive("Team ID is required"),
    content: z.object({
      mapData: z.any(),
      positions: z.array(z.any()),
      annotations: z.array(z.any()),
    }).nullable(),
  });

// Add back the waitlist and events tables with their schemas
export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  teamId: serial("team_id").references(() => teams.id),
  createdById: serial("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Add back the schemas
export const insertWaitlistSchema = createInsertSchema(waitlist)
  .pick({
    email: true,
  })
  .extend({
    email: z.string()
      .email("Please enter a valid email address")
      .refine(
        (email) => {
          const domain = email.split('@')[1];
          return domain === 'gmail.com' || domain === 'hotmail.com';
        },
        "Only Gmail or Hotmail addresses are allowed"
      ),
  });

export const insertEventSchema = createInsertSchema(events)
  .pick({
    title: true,
    description: true,
    startTime: true,
    endTime: true,
    teamId: true,
  })
  .extend({
    title: z.string().min(1, "Title is required"),
    description: z.string().optional(),
    startTime: z.string().transform((str) => new Date(str)),
    endTime: z.string().transform((str) => new Date(str)),
  });

// Add back the types
export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlist.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type Strategy = typeof strategies.$inferSelect;

export type InsertPracticeSchedule = z.infer<typeof insertPracticeScheduleSchema>;
export type PracticeSchedule = typeof practiceSchedules.$inferSelect;