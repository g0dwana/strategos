import { pgTable, text, serial, timestamp, boolean, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Role enum for user types
export const roleEnum = pgEnum("role", ["admin", "manager", "coach", "player"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: roleEnum("role").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  ownerId: serial("owner_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  teamId: serial("team_id").references(() => teams.id),
  userId: serial("user_id").references(() => users.id),
  role: roleEnum("role").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const strategies = pgTable("strategies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  gameType: text("game_type").notNull(),
  content: jsonb("content").notNull(),
  team_id: serial("team_id").references(() => teams.id),
  createdById: serial("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  teamId: serial("team_id").references(() => teams.id),
  createdById: serial("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull().default("todo"),
  teamId: serial("team_id").references(() => teams.id),
  assignedToId: serial("assigned_to_id").references(() => users.id),
  createdById: serial("created_by_id").references(() => users.id),
  dueDate: timestamp("due_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Schema for creating a new team
export const insertTeamSchema = createInsertSchema(teams)
  .pick({
    name: true,
    description: true,
  })
  .extend({
    name: z.string().min(1, "Team name is required"),
    description: z.string().optional(),
  });

// Schema for adding a team member
export const insertTeamMemberSchema = createInsertSchema(teamMembers)
  .pick({
    teamId: true,
    userId: true,
    role: true,
  });

export const insertUserSchema = createInsertSchema(users)
  .pick({
    email: true,
    password: true,
    name: true,
    role: true,
  })
  .extend({
    email: z.string().email("Please enter a valid email address"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    name: z.string().min(2, "Name must be at least 2 characters"),
    role: z.enum(["admin", "manager", "coach", "player"]),
  });

export const insertStrategySchema = createInsertSchema(strategies)
  .pick({
    title: true,
    description: true,
    gameType: true,
    content: true,
    team_id: true,
  })
  .extend({
    title: z.string().min(1, "Title is required").max(100, "Title is too long"),
    description: z.string().min(1, "Description is required").max(500, "Description is too long"),
    gameType: z.string().min(1, "Game type is required"),
    content: z.object({
      mapData: z.any(),
      positions: z.array(z.any()),
      annotations: z.array(z.any()),
    }).nullable(),
  });

export const insertEventSchema = createInsertSchema(events)
  .pick({
    title: true,
    description: true,
    startTime: true,
    endTime: true,
    teamId: true,
  })
  .extend({
    title: z.string().min(1, "Title is required"),
    description: z.string().optional(),
    startTime: z.string().transform((str) => new Date(str)),
    endTime: z.string().transform((str) => new Date(str)),
  });

export const insertTaskSchema = createInsertSchema(tasks)
  .pick({
    title: true,
    description: true,
    status: true,
    teamId: true,
    assignedToId: true,
    dueDate: true,
  })
  .extend({
    title: z.string().min(1, "Title is required"),
    description: z.string().optional(),
    status: z.enum(["todo", "in-progress", "done"]),
    dueDate: z.string().transform((str) => new Date(str)).optional(),
  });

export const insertWaitlistSchema = createInsertSchema(waitlist)
  .pick({
    email: true,
  })
  .extend({
    email: z.string()
      .email("Please enter a valid email address")
      .refine(
        (email) => {
          const domain = email.split('@')[1];
          return domain === 'gmail.com' || domain === 'hotmail.com';
        },
        "Only Gmail or Hotmail addresses are allowed"
      ),
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type Strategy = typeof strategies.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlist.$inferSelect;