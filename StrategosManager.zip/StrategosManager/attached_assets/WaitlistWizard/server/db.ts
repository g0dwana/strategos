
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from 'ws';
import * as schema from '@shared/schema';

// Configure Neon to use WebSocket for serverless connections
neonConfig.webSocketConstructor = ws;

// Validate database configuration
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required');
}

// Initialize database connection pool
export const pool = new Pool({ connectionString: DATABASE_URL });

// Create Drizzle ORM instance with schema
export const db = drizzle({ client: pool, schema });
