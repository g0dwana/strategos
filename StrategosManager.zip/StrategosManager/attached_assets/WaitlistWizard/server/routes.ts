import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema, insertStrategySchema, insertTeamSchema, insertTeamMemberSchema } from "@shared/schema";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express) {
  // Set up authentication routes and middleware
  setupAuth(app);

  // Team routes
  app.post("/api/teams", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const data = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam({
        ...data,
        ownerId: req.user.id,
      });
      res.status(201).json(team);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/teams", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const teams = await storage.getUserTeams(req.user.id);
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/teams/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const teamId = parseInt(req.params.id, 10);
      const team = await storage.getTeam(teamId);

      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      res.json(team);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/teams/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const teamId = parseInt(req.params.id, 10);
      const team = await storage.getTeam(teamId);
      const member = await storage.getTeamMember(teamId, req.user.id);

      if (!team || !member || member.role !== "manager") {
        return res.status(403).json({ message: "Not authorized to delete this team" });
      }

      await storage.deleteTeam(teamId);
      res.json({ message: "Team deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/teams/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const teamId = parseInt(req.params.id, 10);
      const team = await storage.getTeam(teamId);

      if (!team || team.ownerId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this team" });
      }

      const updatedTeam = await storage.updateTeam(teamId, req.body);
      res.json(updatedTeam);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/teams/:teamId/members", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const teamId = parseInt(req.params.teamId, 10);
      const team = await storage.getTeam(teamId);

      if (!team || team.ownerId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to manage this team" });
      }

      const { email, role } = req.body;
      if (!email || !role || !["player", "coach"].includes(role)) {
        return res.status(400).json({ message: "Invalid email or role" });
      }

      const member = await storage.addTeamMember(teamId, email, role);
      if (!member) {
        return res.status(404).json({ message: "User with this email not found" });
      }

      res.status(201).json(member);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/teams/:id/members", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    try {
      const teamId = parseInt(req.params.id, 10);
      const members = await storage.getTeamMembers(teamId);
      if (!members) {
        return res.status(404).json({ message: "Team members not found" });
      }
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/teams/:teamId/members/:userId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const teamId = parseInt(req.params.teamId, 10);
      const userId = parseInt(req.params.userId, 10);
      await storage.removeTeamMember(teamId, userId);
      res.json({ message: "Member removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Strategy routes
  app.post("/api/strategies", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const data = insertStrategySchema.parse(req.body);
      const strategy = await storage.createStrategy({
        ...data,
        createdById: req.user.id,
      });
      res.status(201).json(strategy);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/strategies", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const strategies = await storage.getUserStrategies(req.user.id);
      res.json(strategies);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Event routes
  app.post("/api/events", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const data = insertEventSchema.parse(req.body);
      const event = await storage.createEvent({
        ...data,
        createdById: req.user.id,
      });

      // Schedule email notification
      const startTime = new Date(data.startTime);
      const notificationTime = new Date(startTime.getTime() - 60 * 60 * 1000); // 1 hour before
      const now = new Date();

      if (notificationTime > now) {
        setTimeout(async () => {
          const user = await storage.getUser(req.user.id);
          // Send email using your email service
          console.log(`Sending notification email to ${user.email} for event ${event.title}`);
        }, notificationTime.getTime() - now.getTime());
      }

      res.status(201).json(event);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/events", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const events = await storage.getTeamEvents(req.user.id);
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/strategies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const strategy = await storage.getStrategy(id);

      if (!strategy) {
        return res.status(404).json({ message: "Strategy not found" });
      }

      res.json(strategy);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Existing waitlist route
  app.post("/api/waitlist", async (req, res) => {
    try {
      const data = insertWaitlistSchema.parse(req.body);

      const isRegistered = await storage.isEmailRegistered(data.email);
      if (isRegistered) {
        return res.status(400).json({ 
          message: "This email is already registered" 
        });
      }

      const entry = await storage.addToWaitlist(data);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  return createServer(app);
}