import { type Waitlist, type InsertWaitlist, type Strategy, type InsertStrategy, type User, type InsertUser, type Team, type InsertTeam, type TeamMember, type InsertTeamMember } from "@shared/schema";
import { waitlist, strategies, users, teams, teamMembers } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;

  // Team operations
  createTeam(team: InsertTeam & { ownerId: number }): Promise<Team>;
  getTeam(id: number): Promise<Team | undefined>;
  getUserTeams(userId: number): Promise<Team[]>;
  addTeamMember(teamId: number, email: string, role: string): Promise<TeamMember & { user: User }>;
  removeTeamMember(teamId: number, userId: number): Promise<void>;
  getTeamMembers(teamId: number): Promise<(TeamMember & { user: User })[]>;

  // Strategy operations
  createStrategy(strategy: InsertStrategy & { createdById: number }): Promise<Strategy>;
  getStrategy(id: number): Promise<Strategy | undefined>;
  getTeamStrategies(teamId: number): Promise<Strategy[]>;
  getUserStrategies(userId: number): Promise<Strategy[]>;

  // Waitlist operations
  addToWaitlist(entry: InsertWaitlist): Promise<Waitlist>;
  isEmailRegistered(email: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    return newUser;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    return user;
  }

  // Team methods
  async createTeam(team: InsertTeam & { ownerId: number }): Promise<Team> {
    const [newTeam] = await db
      .insert(teams)
      .values(team)
      .returning();

    // Add owner as a team member with their current role
    const owner = await this.getUser(team.ownerId);
    if (owner) {
      await this.addTeamMember(newTeam.id, owner.email, owner.role);
    }

    return newTeam;
  }

  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db
      .select()
      .from(teams)
      .where(eq(teams.id, id));
    return team;
  }

  async getUserTeams(userId: number): Promise<Team[]> {
    return db
      .select()
      .from(teams)
      .where(
        or(
          eq(teams.ownerId, userId),
          inArray(
            teams.id,
            db
              .select({ teamId: teamMembers.teamId })
              .from(teamMembers)
              .where(eq(teamMembers.userId, userId))
          )
        )
      );
  }

  async deleteTeam(teamId: number): Promise<void> {
    await db.delete(teamMembers).where(eq(teamMembers.teamId, teamId));
    await db.delete(teams).where(eq(teams.id, teamId));
  }

  async updateTeam(teamId: number, data: Partial<Team>): Promise<Team> {
    const [updatedTeam] = await db
      .update(teams)
      .set({
        name: data.name,
        description: data.description,
        updatedAt: new Date(),
      })
      .where(eq(teams.id, teamId))
      .returning();
    return updatedTeam;
  }

  async addTeamMember(teamId: number, email: string, role: string): Promise<TeamMember & { user: User }> {
    const user = await this.getUserByEmail(email);
    if (!user) {
      throw new Error("User not found");
    }

    const [member] = await db
      .insert(teamMembers)
      .values({
        teamId,
        userId: user.id,
        role: role as any,
      })
      .returning();

    return { ...member, user };
  }

  async removeTeamMember(teamId: number, userId: number): Promise<void> {
    await db
      .delete(teamMembers)
      .where(
        and(
          eq(teamMembers.teamId, teamId),
          eq(teamMembers.userId, userId)
        )
      );
  }

  async getTeamMembers(teamId: number): Promise<(TeamMember & { user: User })[]> {
    const members = await db
      .select({
        member: teamMembers,
        user: users,
      })
      .from(teamMembers)
      .where(eq(teamMembers.teamId, teamId))
      .innerJoin(users, eq(users.id, teamMembers.userId));

    return members.map(m => ({ ...m.member, user: m.user }));
  }

  // Strategy methods
  async createStrategy(strategy: InsertStrategy & { createdById: number }): Promise<Strategy> {
    const [newStrategy] = await db
      .insert(strategies)
      .values(strategy)
      .returning();
    return newStrategy;
  }

  async getStrategy(id: number): Promise<Strategy | undefined> {
    const [strategy] = await db
      .select()
      .from(strategies)
      .where(eq(strategies.id, id));
    return strategy;
  }

  async getTeamStrategies(teamId: number): Promise<Strategy[]> {
    return db
      .select()
      .from(strategies)
      .where(eq(strategies.teamId, teamId))
      .orderBy(desc(strategies.createdAt));
  }

  async getUserStrategies(userId: number): Promise<Strategy[]> {
    const userTeams = await this.getUserTeams(userId);
    const teamIds = userTeams.map(team => team.id);

    return db
      .select()
      .from(strategies)
      .where(eq(strategies.teamId, teamIds[0])) // TODO: Use 'in' operator when supported
      .orderBy(desc(strategies.createdAt));
  }

  // Waitlist methods
  async addToWaitlist(entry: InsertWaitlist): Promise<Waitlist> {
    const [waitlistEntry] = await db
      .insert(waitlist)
      .values(entry)
      .returning();
    return waitlistEntry;
  }

  async isEmailRegistered(email: string): Promise<boolean> {
    const [entry] = await db
      .select()
      .from(waitlist)
      .where(eq(waitlist.email, email));
    return !!entry;
  }
}

export const storage = new DatabaseStorage();