
import express, { type Request, Response, NextFunction } from 'express';
import { registerRoutes } from './routes';
import { setupVite, serveStatic, log } from './vite';

// Initialize Express app
const app = express();

// Configure middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Request logging middleware
app.use((req, res, next) => {
  if (!req.path.startsWith('/api')) {
    return next();
  }

  const start = Date.now();
  let responseBody: Record<string, any> | undefined;

  // Capture JSON response for logging
  const originalJson = res.json;
  res.json = function(body, ...args) {
    responseBody = body;
    return originalJson.apply(res, [body, ...args]);
  };

  // Log API requests on completion
  res.on('finish', () => {
    const duration = Date.now() - start;
    const logMessage = `${req.method} ${req.path} ${res.statusCode} in ${duration}ms`;
    const fullLog = responseBody ? `${logMessage} :: ${JSON.stringify(responseBody)}` : logMessage;
    log(fullLog.length > 80 ? `${fullLog.slice(0, 79)}…` : fullLog);
  });

  next();
});

// Start server
(async () => {
  const server = await registerRoutes(app);

  // Global error handler
  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    const status = 'status' in err ? Number(err.status) || 500 : 500;
    res.status(status).json({ message: err.message || 'Internal Server Error' });
    throw err;
  });

  // Setup Vite in development
  if (app.get('env') === 'development') {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Start server on port 5000
  server.listen({
    port: 5000,
    host: '0.0.0.0',
    reusePort: true,
  }, () => {
    log('Server running on port 5000');
  });
})();
