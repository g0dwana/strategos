import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/components/protected-route";
import { NavBar } from "@/components/nav-bar";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Strategies from "@/pages/strategies";
import CreateStrategy from "@/pages/create-strategy";
import Teams from "@/pages/teams";
import CreateTeam from "@/pages/create-team";
import TeamDetail from "@/pages/team-detail";
import AuthPage from "@/pages/auth";
import Events from "@/pages/events";
import EditTeam from "@/pages/edit-team";


function Router() {
  return (
    <>
      <NavBar />
      <main>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/auth" component={AuthPage} />
          <ProtectedRoute 
            path="/strategies" 
            component={Strategies} 
            allowedRoles={["admin", "manager", "player", "coach"]}
          />
          <ProtectedRoute 
            path="/strategies/new" 
            component={CreateStrategy}
            allowedRoles={["admin", "manager", "coach"]} 
          />
          <ProtectedRoute 
            path="/teams" 
            component={Teams} 
            allowedRoles={["admin", "manager", "player", "coach"]}
          />
          <ProtectedRoute 
            path="/teams/new" 
            component={CreateTeam} 
            allowedRoles={["admin", "manager"]}
          />
          <ProtectedRoute 
            path="/teams/:id" 
            component={TeamDetail} 
            allowedRoles={["admin", "manager", "player", "coach"]}
          />
          <ProtectedRoute 
            path="/teams/:id/edit" 
            component={EditTeam}
            allowedRoles={["manager"]}
          />
          <ProtectedRoute 
            path="/teams/:id/members" 
            component={TeamDetail}
            allowedRoles={["admin", "manager", "coach"]}
          />
          <ProtectedRoute path="/events" component={Events} allowedRoles={["admin", "manager", "player", "coach"]}/>
          <Route component={NotFound} />
        </Switch>
      </main>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;