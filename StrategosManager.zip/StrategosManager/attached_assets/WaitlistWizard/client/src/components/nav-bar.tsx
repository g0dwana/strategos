import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LogOut, Users } from "lucide-react";

export function NavBar() {
  const { user, logout } = useAuth();

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <Link href="/">
            <span className="font-bold text-xl">Strategos</span>
          </Link>
          {user && (
            <>
              <Link href="/teams" className="text-muted-foreground hover:text-foreground transition-colors">
                Teams
              </Link>
              <Link href="/strategies" className="text-muted-foreground hover:text-foreground transition-colors">
                Strategies
              </Link>
              <Link href="/events" className="text-muted-foreground hover:text-foreground transition-colors">
                Calendar
              </Link>
            </>
          )}
        </div>

        <div>
          {user ? (
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                Welcome, {user.name}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => logout()}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          ) : (
            <Link href="/auth">
              <Button>Login</Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}