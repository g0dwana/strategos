import { type Strategy } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

interface StrategyCardProps {
  strategy: Strategy;
  onClick?: () => void;
}

export function StrategyCard({ strategy, onClick }: StrategyCardProps) {
  return (
    <Card 
      className="hover:border-primary/40 transition-colors cursor-pointer" 
      onClick={onClick}
    >
      <CardHeader>
        <div className="flex justify-between items-start mb-2">
          <CardTitle className="text-xl">{strategy.title}</CardTitle>
          <Badge variant="secondary">{strategy.gameType}</Badge>
        </div>
        <CardDescription className="line-clamp-2">
          {strategy.description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>Team Strategy</span>
          <span>
            {formatDistanceToNow(new Date(strategy.createdAt), { addSuffix: true })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}