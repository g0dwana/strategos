import { useQuery, useMutation } from "@tanstack/react-query";
import { type Team, type TeamMember, type User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useParams, useLocation } from "wouter";
import { useState } from "react";
import { Link } from "wouter";


export default function TeamDetail() {
  const { toast } = useToast();
  const params = useParams();
  const teamId = parseInt(params.id, 10);
  const [, setLocation] = useLocation();
  const [newMemberEmail, setNewMemberEmail] = useState("");
  const [newMemberRole, setNewMemberRole] = useState<"player" | "coach">("player");

  // Assuming user role is fetched elsewhere and available here.  Replace with your actual role fetching mechanism.
  const userRole = localStorage.getItem("userRole") as "manager" | "player" | "coach" | null;
  const isManager = userRole === "manager";


  const { data: team, isLoading: isLoadingTeam } = useQuery<Team>({
    queryKey: ["/api/teams", teamId],
    queryFn: () => apiRequest("GET", `/api/teams/${teamId}`).then(res => res.json()),
  });

  const { data: members, isLoading: isLoadingMembers } = useQuery<(TeamMember & { user: User })[]>({
    queryKey: ["/api/teams", teamId, "members"],
    queryFn: () => apiRequest("GET", `/api/teams/${teamId}/members`).then(res => res.json()),
  });

  const addMemberMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/teams/${teamId}/members`, {
        email: newMemberEmail,
        role: newMemberRole,
      });
      if (!res.ok) throw new Error("Failed to add member");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "members"] });
      setNewMemberEmail("");
      toast({ title: "Success", description: "Member added successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/teams/${teamId}`);
      if (!res.ok) throw new Error("Failed to delete team");
      return res.json();
    },
    onSuccess: () => {
      setLocation("/teams");
      toast({ title: "Success", description: "Team deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  const removeMemberMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("DELETE", `/api/teams/${teamId}/members/${userId}`);
      if (!res.ok) throw new Error("Failed to remove member");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "members"] });
      toast({ title: "Success", description: "Member removed successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  if (isLoadingTeam || isLoadingMembers) {
    return <div>Loading team details...</div>;
  }

  if (!team) {
    return <div className="container mx-auto py-8 px-4">Team not found</div>;
  }

  const handleAddMember = () => {
    if (!newMemberEmail) {
      toast({ variant: "destructive", title: "Error", description: "Please enter member email" });
      return;
    }
    addMemberMutation.mutate();
  };

  const handleRemoveMember = (userId: number) => {
    if (confirm("Are you sure you want to remove this member?")) {
      removeMemberMutation.mutate(userId);
    }
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this team?")) {
      deleteMutation.mutate();
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{team.name}</h1>
        {isManager && (
          <div className="space-x-4">
            <Link href={`/teams/${teamId}/edit`}>
              <Button variant="outline">Edit Team</Button>
            </Link>
            <Button variant="destructive" onClick={() => handleDelete()}>
              Delete Team
            </Button>
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {userRole === "manager" || userRole === "coach" ? (
          <div>
            <h2 className="text-2xl font-semibold mb-4">Team Members</h2>
            <div className="space-y-4">
              <div className="flex gap-4 mb-6">
                <Input
                  placeholder="Member email"
                  value={newMemberEmail}
                  onChange={(e) => setNewMemberEmail(e.target.value)}
                />
                <Select value={newMemberRole} onValueChange={(value: "player" | "coach") => setNewMemberRole(value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="player">Player</SelectItem>
                    <SelectItem value="coach">Coach</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={handleAddMember}>Add Member</Button>
              </div>
              {members?.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">{member.user.name}</p>
                    <p className="text-sm text-muted-foreground">{member.role}</p>
                  </div>
                  {userRole === "manager" && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleRemoveMember(member.user.id)}
                    >
                      Remove
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}