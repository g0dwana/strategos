import { useQuery } from "@tanstack/react-query";
import { type Strategy } from "@shared/schema";
import { StrategyCard } from "@/components/strategy-card";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Link } from "wouter";
import { useEffect } from "react";

export default function Strategies() {
  const { toast } = useToast();

  const { data: strategies, isLoading, error } = useQuery<Strategy[]>({
    queryKey: ["/api/strategies"],
  });

  useEffect(() => {
    if (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load strategies",
      });
    }
  }, [error, toast]);

  if (isLoading) {
    return <div>Loading strategies...</div>;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Team Strategies</h1>
        <Link href="/strategies/new">
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Strategy
          </Button>
        </Link>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {strategies?.map((strategy) => (
          <Link key={strategy.id} href={`/strategies/${strategy.id}`}>
            <StrategyCard strategy={strategy} />
          </Link>
        ))}
      </div>
    </div>
  );
}