import { useQuery, useMutation } from "@tanstack/react-query";
import { type Team, type InsertTeam } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Teams() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: teams, isLoading } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
    queryFn: () => apiRequest("GET", "/api/teams").then(res => res.json()),
  });

  const deleteMutation = useMutation({
    mutationFn: async (teamId: number) => {
      const res = await apiRequest("DELETE", `/api/teams/${teamId}`);
      if (!res.ok) throw new Error("Failed to delete team");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({ title: "Success", description: "Team deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  if (isLoading) {
    return <div>Loading teams...</div>;
  }

  const handleDelete = (e: React.MouseEvent, teamId: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this team?")) {
      deleteMutation.mutate(teamId);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Teams</h1>
        <Link href="/teams/new">
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Team
          </Button>
        </Link>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teams?.map((team) => (
          <div key={team.id} className="border rounded-lg p-6 hover:border-primary/40 transition-colors">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-semibold">{team.name}</h3>
              <div className="flex gap-2">
                <Link href={`/teams/${team.id}/edit`}>
                  <Button variant="outline" size="sm">Edit</Button>
                </Link>
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={(e) => handleDelete(e, team.id)}
                >
                  Delete
                </Button>
              </div>
            </div>
            {team.description && (
              <p className="text-muted-foreground mb-4">{team.description}</p>
            )}
            <div className="flex justify-between items-center">
              <Link href={`/teams/${team.id}`}>
                <Button variant="link">View Details</Button>
              </Link>
              <Link href={`/teams/${team.id}/members`}>
                <Button variant="outline">Manage Members</Button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
