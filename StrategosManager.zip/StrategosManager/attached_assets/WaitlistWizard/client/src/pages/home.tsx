import { AnimatedSection } from "@/components/animated-section";
import { WaitlistForm } from "@/components/waitlist-form";
import { FeatureCard } from "@/components/feature-card";
import { Target, Users, Trophy, Brain, Zap, ArrowUpRight } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="relative py-24 px-4">
        <AnimatedSection className="container mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Level Up Your Esports Strategy
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Strategos helps esports teams make data-driven decisions and dominate the competition
          </p>
          <WaitlistForm />
        </AnimatedSection>
      </section>

      {/* Features Grid */}
      <section className="py-24 px-4 bg-black/20">
        <div className="container mx-auto">
          <AnimatedSection className="text-center mb-16" delay={0.2}>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Master the Game of Strategy
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to analyze, plan, and execute winning strategies
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatedSection delay={0.3}>
              <FeatureCard
                icon={Brain}
                title="AI-Powered Analysis"
                description="Advanced analytics and insights powered by machine learning"
              />
            </AnimatedSection>
            <AnimatedSection delay={0.4}>
              <FeatureCard
                icon={Users}
                title="Team Management"
                description="Streamline communication and coordinate your roster"
              />
            </AnimatedSection>
            <AnimatedSection delay={0.5}>
              <FeatureCard
                icon={Target}
                title="Strategy Builder"
                description="Create and share detailed game plans with your team"
              />
            </AnimatedSection>
            <AnimatedSection delay={0.6}>
              <FeatureCard
                icon={Trophy}
                title="Tournament Tools"
                description="Track performance and analyze competition data"
              />
            </AnimatedSection>
            <AnimatedSection delay={0.7}>
              <FeatureCard
                icon={Zap}
                title="Real-time Updates"
                description="Stay informed with live game data and analytics"
              />
            </AnimatedSection>
            <AnimatedSection delay={0.8}>
              <FeatureCard
                icon={ArrowUpRight}
                title="Performance Tracking"
                description="Monitor progress and identify areas for improvement"
              />
            </AnimatedSection>
          </div>
        </div>
      </section>
    </div>
  );
}
