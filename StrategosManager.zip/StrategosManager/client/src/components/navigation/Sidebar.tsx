import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { LayoutDashboard, Users, Map, ClipboardList } from "lucide-react";

const MENU_ITEMS = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/" },
  { icon: Users, label: "Team", href: "/team" },
  { icon: Map, label: "Strategy", href: "/strategy" },
  { icon: ClipboardList, label: "Tasks", href: "/tasks" }
];

export function Sidebar() {
  return (
    <div className="w-64 h-screen bg-sidebar border-r border-sidebar-border flex flex-col">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-sidebar-foreground">Strategos</h1>
      </div>

      <nav className="flex-1">
        {MENU_ITEMS.map(({ icon: Icon, label, href }) => (
          <Link key={href} href={href}>
            <a className={cn(
              "flex items-center gap-3 px-6 py-3 text-sidebar-foreground",
              "hover:bg-sidebar-accent transition-colors",
              "cursor-pointer"
            )}>
              <Icon className="h-5 w-5" />
              <span>{label}</span>
            </a>
          </Link>
        ))}
      </nav>
    </div>
  );
}
