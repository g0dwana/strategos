import { Button } from "@/components/ui/button";
import { Pencil, Eraser, MapPin, Type } from "lucide-react";

const TOOL_ICONS = {
  pen: Pencil,
  eraser: Eraser,
  marker: MapPin,
  text: Type
};

interface ToolsProps {
  tools: readonly string[];
  selected: string;
  onSelect: (tool: string) => void;
}

export function Tools({ tools, selected, onSelect }: ToolsProps) {
  return (
    <div className="flex flex-col gap-2">
      {tools.map(tool => {
        const Icon = TOOL_ICONS[tool as keyof typeof TOOL_ICONS];
        return (
          <Button
            key={tool}
            variant={selected === tool ? "default" : "outline"}
            size="icon"
            onClick={() => onSelect(tool)}
          >
            <Icon className="h-4 w-4" />
          </Button>
        );
      })}
    </div>
  );
}
