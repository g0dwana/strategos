import { useState } from "react";
import { Canvas } from "@/components/map/Canvas";
import { Tools } from "@/components/map/Tools";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useParams } from "wouter";

const TOOLS = ["pen", "eraser", "marker", "text"] as const;
type Tool = typeof TOOLS[number];

export default function StrategyBoard() {
  const { teamId } = useParams();
  const [selectedTool, setSelectedTool] = useState<Tool>("pen");
  const [name, setName] = useState("");
  const { toast } = useToast();

  const handleSave = async (mapData: any) => {
    try {
      await apiRequest("POST", "/api/strategies", {
        name,
        teamId: Number(teamId),
        mapData
      });
      toast({
        title: "Strategy saved",
        description: "Your strategy has been saved successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save strategy",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="p-6 h-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Strategy Board</h1>
        <div className="flex gap-4">
          <input
            type="text"
            placeholder="Strategy name"
            className="px-3 py-2 border rounded"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <Button onClick={() => handleSave({})}>Save Strategy</Button>
        </div>
      </div>

      <div className="flex gap-6">
        <Tools
          tools={TOOLS}
          selected={selectedTool}
          onSelect={setSelectedTool}
        />
        <Canvas tool={selectedTool} />
      </div>
    </div>
  );
}
