import { useQuery } from "@tanstack/react-query";
import { type Strategy } from "@shared/schema";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";

export default function StrategyDetail() {
  const params = useParams<{ id: string }>();
  const strategyId = params?.id ? parseInt(params.id, 10) : 0;

  const { data: strategy, isLoading } = useQuery<Strategy>({
    queryKey: ["/api/strategies", strategyId],
    queryFn: () => apiRequest("GET", `/api/strategies/${strategyId}`).then(res => res.json()),
  });

  if (isLoading) {
    return <div>Loading strategy...</div>;
  }

  if (!strategy) {
    return <div>Strategy not found</div>;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card>
        <CardHeader>
          <CardTitle>{strategy.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Description</h3>
              <p>{strategy.description}</p>
            </div>
            <div>
              <h3 className="font-semibold">Game Type</h3>
              <p>{strategy.gameType}</p>
            </div>
            {strategy.content && (
              <div>
                <h3 className="font-semibold">Strategy Details</h3>
                <pre className="mt-2 p-4 bg-muted rounded-lg overflow-auto">
                  {JSON.stringify(strategy.content, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
