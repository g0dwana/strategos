import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { type Team, type InsertTeam, insertTeamSchema } from "@shared/schema";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation, useParams } from "wouter";

export default function EditTeam() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const params = useParams<{ id: string }>();
  const teamId = params?.id ? parseInt(params.id, 10) : 0;

  const { data: team, isLoading } = useQuery<Team>({
    queryKey: ["/api/teams", teamId],
    queryFn: () => apiRequest("GET", `/api/teams/${teamId}`).then(res => res.json()),
  });

  const form = useForm<InsertTeam>({
    resolver: zodResolver(insertTeamSchema),
    values: team ? {
      name: team.name,
      description: team.description || "",
      game: team.game || "",
      division: team.division || "",
      achievements: team.achievements || [],
      stats: team.stats || {
        wins: 0,
        losses: 0,
        winRate: 0,
        lastUpdated: new Date().toISOString()
      }
    } : {
      name: "",
      description: "",
      game: "",
      division: "",
      achievements: [],
      stats: {
        wins: 0,
        losses: 0,
        winRate: 0,
        lastUpdated: new Date().toISOString()
      }
    }
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertTeam) => {
      const res = await apiRequest("PUT", `/api/teams/${teamId}`, data);
      if (!res.ok) throw new Error("Failed to update team");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Success!",
        description: "Team updated successfully.",
      });
      setLocation("/teams");
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    },
  });

  const onSubmit = form.handleSubmit((data) => {
    mutation.mutate(data);
  });

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Edit Team</h1>
        <Form {...form}>
          <form onSubmit={onSubmit} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Team Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter team name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Team description" 
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="game"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Game</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Primary game (e.g., CS:GO, Valorant, LoL)" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="division"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Division</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Competitive division/tier" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "Updating..." : "Update Team"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}