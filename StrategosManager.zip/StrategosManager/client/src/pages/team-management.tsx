import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Player, Team } from "@shared/schema";
import { useParams } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function TeamManagement() {
  const { teamId } = useParams();
  const { toast } = useToast();

  const { data: team } = useQuery<Team>({ 
    queryKey: [`/api/teams/${teamId}`]
  });

  const { data: players } = useQuery<Player[]>({ 
    queryKey: [`/api/teams/${teamId}/players`]
  });

  const addPlayerMutation = useMutation({
    mutationFn: async (username: string) => {
      return apiRequest("POST", "/api/players", {
        username,
        teamId: Number(teamId)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${teamId}/players`] });
      toast({
        title: "Player added",
        description: "New player has been added to the team"
      });
    }
  });

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle>{team?.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Team Members</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {players?.map(player => (
              <Card key={player.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="font-medium">{player.username}</p>
                      <p className="text-sm text-muted-foreground">{player.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
