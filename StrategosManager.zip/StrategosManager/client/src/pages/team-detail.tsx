import { useQuery, useMutation } from "@tanstack/react-query";
import { type Team, type TeamMember, type User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useParams, useLocation } from "wouter";
import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";

export default function TeamDetail() {
  const { toast } = useToast();
  const params = useParams<{ id: string }>();
  const teamId = params?.id ? parseInt(params.id, 10) : 0;
  const [, setLocation] = useLocation();
  const [newMemberEmail, setNewMemberEmail] = useState("");
  const [newMemberRole, setNewMemberRole] = useState<"player" | "coach">("player");

  const { data: team, isLoading: isLoadingTeam } = useQuery<Team>({
    queryKey: ["/api/teams", teamId],
    queryFn: () => apiRequest("GET", `/api/teams/${teamId}`).then(res => res.json()),
  });

  const { data: members, isLoading: isLoadingMembers } = useQuery<(TeamMember & { user: User })[]>({
    queryKey: ["/api/teams", teamId, "members"],
    queryFn: () => apiRequest("GET", `/api/teams/${teamId}/members`).then(res => res.json()),
  });

  const addMemberMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/teams/${teamId}/members`, {
        email: newMemberEmail,
        role: newMemberRole,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to add member");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "members"] });
      setNewMemberEmail("");
      toast({ title: "Success", description: "Member added successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/teams/${teamId}`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to delete team");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      setLocation("/teams");
      toast({ title: "Success", description: "Team deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  const removeMemberMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("DELETE", `/api/teams/${teamId}/members/${userId}`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to remove member");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "members"] });
      toast({ title: "Success", description: "Member removed successfully" });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  });

  if (isLoadingTeam || isLoadingMembers) {
    return <div>Loading team details...</div>;
  }

  if (!team) {
    return <div className="container mx-auto py-8 px-4">Team not found</div>;
  }

  const handleAddMember = () => {
    if (!newMemberEmail) {
      toast({ variant: "destructive", title: "Error", description: "Please enter member email" });
      return;
    }
    addMemberMutation.mutate();
  };

  const handleRemoveMember = (userId: number) => {
    if (confirm("Are you sure you want to remove this member?")) {
      removeMemberMutation.mutate(userId);
    }
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this team?")) {
      deleteMutation.mutate();
    }
  };

  const isManager = team.ownerId === parseInt(localStorage.getItem("userId") || "0");

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">{team.name}</h1>
          {team.game && (
            <p className="text-muted-foreground mt-2">
              Game: {team.game} {team.division && `- Division: ${team.division}`}
            </p>
          )}
        </div>
        {isManager && (
          <div className="space-x-4">
            <Link href={`/teams/${teamId}/edit`}>
              <Button variant="outline">Edit Team</Button>
            </Link>
            <Button variant="destructive" onClick={handleDelete}>
              Delete Team
            </Button>
          </div>
        )}
      </div>

      <Tabs defaultValue="members" className="space-y-4">
        <TabsList>
          <TabsTrigger value="members">Members</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="stats">Team Stats</TabsTrigger>
        </TabsList>

        <TabsContent value="members">
          <Card>
            <CardHeader>
              <CardTitle>Team Members</CardTitle>
            </CardHeader>
            <CardContent>
              {isManager && (
                <div className="flex gap-4 mb-6">
                  <Input
                    placeholder="Member email"
                    value={newMemberEmail}
                    onChange={(e) => setNewMemberEmail(e.target.value)}
                  />
                  <Select value={newMemberRole} onValueChange={(value: "player" | "coach") => setNewMemberRole(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="player">Player</SelectItem>
                      <SelectItem value="coach">Coach</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleAddMember}>Add Member</Button>
                </div>
              )}
              <div className="space-y-4">
                {members?.map((member) => (
                  <Card key={member.id}>
                    <CardContent className="flex items-center justify-between p-4">
                      <div>
                        <p className="font-medium">{member.user.name}</p>
                        <p className="text-sm text-muted-foreground">{member.role}</p>
                        {member.nickname && (
                          <p className="text-sm text-muted-foreground">IGN: {member.nickname}</p>
                        )}
                      </div>
                      {isManager && member.user.id !== team.ownerId && (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleRemoveMember(member.user.id)}
                        >
                          Remove
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements">
          <Card>
            <CardHeader>
              <CardTitle>Team Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              {team.achievements && team.achievements.length > 0 ? (
                <div className="space-y-4">
                  {team.achievements.map((achievement, index) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <h3 className="font-semibold">{achievement.title}</h3>
                        <p className="text-sm text-muted-foreground">{achievement.date}</p>
                        {achievement.description && (
                          <p className="mt-2">{achievement.description}</p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No achievements recorded yet.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>Team Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              {team.stats ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-2xl font-bold">{team.stats.wins}</p>
                      <p className="text-sm text-muted-foreground">Wins</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-2xl font-bold">{team.stats.losses}</p>
                      <p className="text-sm text-muted-foreground">Losses</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-2xl font-bold">{team.stats.winRate}%</p>
                      <p className="text-sm text-muted-foreground">Win Rate</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-muted-foreground">Last Updated</p>
                      <p>{format(new Date(team.stats.lastUpdated), 'MMM d, yyyy')}</p>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <p className="text-muted-foreground">No statistics available yet.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}