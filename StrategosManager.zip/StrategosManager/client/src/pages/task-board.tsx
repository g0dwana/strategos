import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Task } from "@shared/schema";
import { useParams } from "wouter";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { apiRequest, queryClient } from "@/lib/queryClient";

const COLUMNS = ["Todo", "In Progress", "Done"];

export default function TaskBoard() {
  const { teamId } = useParams();

  const { data: tasks } = useQuery<Task[]>({ 
    queryKey: [`/api/teams/${teamId}/tasks`]
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, status }: { taskId: number; status: string }) => {
      return apiRequest("PATCH", `/api/tasks/${taskId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${teamId}/tasks`] });
    }
  });

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const taskId = Number(result.draggableId);
    const newStatus = result.destination.droppableId;
    
    updateTaskMutation.mutate({ taskId, status: newStatus });
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Task Board</h1>

      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {COLUMNS.map(column => (
            <div key={column}>
              <h2 className="text-xl font-semibold mb-4">{column}</h2>
              <Droppable droppableId={column}>
                {(provided) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="space-y-4"
                  >
                    {tasks?.filter(task => task.status === column).map((task, index) => (
                      <Draggable
                        key={task.id}
                        draggableId={String(task.id)}
                        index={index}
                      >
                        {(provided) => (
                          <Card
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <CardContent className="pt-6">
                              <h3 className="font-medium">{task.title}</h3>
                              <p className="text-sm text-muted-foreground">
                                {task.description}
                              </p>
                            </CardContent>
                          </Card>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>
    </div>
  );
}
