import { type Strategy, type InsertStrategy, type User, type InsertUser, type Team, type InsertTeam, type TeamMember, type InsertTeamMember, type PracticeSchedule, type Event, type InsertEvent, type Waitlist, type InsertWaitlist } from "@shared/schema";
import { strategies, users, teams, teamMembers, practiceSchedules, events, waitlist } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;

  // Team operations
  createTeam(team: InsertTeam & { ownerId: number }): Promise<Team>;
  getTeam(id: number): Promise<Team | undefined>;
  getUserTeams(userId: number): Promise<Team[]>;
  addTeamMember(teamId: number, email: string, role: string): Promise<TeamMember & { user: User }>;
  removeTeamMember(teamId: number, userId: number): Promise<void>;
  getTeamMembers(teamId: number): Promise<(TeamMember & { user: User })[]>;
  updateTeam(teamId: number, data: Partial<Team>): Promise<Team>;
  deleteTeam(teamId: number): Promise<void>;

  // Strategy operations
  createStrategy(strategy: InsertStrategy & { createdById: number }): Promise<Strategy>;
  getStrategy(id: number): Promise<Strategy | undefined>;
  getTeamStrategies(teamId: number): Promise<Strategy[]>;
  getUserStrategies(userId: number): Promise<Strategy[]>;

  // Event operations
  createEvent(event: InsertEvent & { createdById: number }): Promise<Event>;
  getTeamEvents(teamId: number): Promise<Event[]>;

  // Waitlist operations
  addToWaitlist(entry: InsertWaitlist): Promise<Waitlist>;
  isEmailRegistered(email: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    return newUser;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    return user;
  }

  // Team methods
  async createTeam(team: InsertTeam & { ownerId: number }): Promise<Team> {
    const [newTeam] = await db
      .insert(teams)
      .values(team)
      .returning();

    // Add owner as a team member with their current role
    const owner = await this.getUser(team.ownerId);
    if (owner) {
      await this.addTeamMember(newTeam.id, owner.email, owner.role);
    }

    return newTeam;
  }

  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db
      .select()
      .from(teams)
      .where(eq(teams.id, id));
    return team;
  }

  async getUserTeams(userId: number): Promise<Team[]> {
    return db
      .select()
      .from(teams)
      .where(
        or(
          eq(teams.ownerId, userId),
          inArray(
            teams.id,
            db
              .select({ teamId: teamMembers.teamId })
              .from(teamMembers)
              .where(eq(teamMembers.userId, userId))
          )
        )
      );
  }

  async deleteTeam(teamId: number): Promise<void> {
    try {
      // Delete related records first
      await db.delete(teamMembers).where(eq(teamMembers.teamId, teamId));
      await db.delete(strategies).where(eq(strategies.team_id, teamId));
      // Finally delete the team
      await db.delete(teams).where(eq(teams.id, teamId));
    } catch (error) {
      console.error('Error in deleteTeam:', error);
      throw error;
    }
  }

  async updateTeam(teamId: number, data: Partial<Team>): Promise<Team> {
    const [updatedTeam] = await db
      .update(teams)
      .set({
        name: data.name,
        description: data.description,
        game: data.game,
        division: data.division,
        achievements: data.achievements,
        stats: data.stats,
        updatedAt: new Date(),
      })
      .where(eq(teams.id, teamId))
      .returning();
    return updatedTeam;
  }

  async addTeamMember(teamId: number, email: string, role: string): Promise<TeamMember & { user: User }> {
    const user = await this.getUserByEmail(email);
    if (!user) {
      throw new Error("User not found");
    }

    const [member] = await db
      .insert(teamMembers)
      .values({
        teamId,
        userId: user.id,
        role: role as any,
        joinedAt: new Date(),
        active: true,
      })
      .returning();

    return { ...member, user };
  }

  async removeTeamMember(teamId: number, userId: number): Promise<void> {
    await db
      .delete(teamMembers)
      .where(
        and(
          eq(teamMembers.teamId, teamId),
          eq(teamMembers.userId, userId)
        )
      );
  }

  async getTeamMembers(teamId: number): Promise<(TeamMember & { user: User })[]> {
    const members = await db
      .select({
        member: teamMembers,
        user: users,
      })
      .from(teamMembers)
      .where(eq(teamMembers.teamId, teamId))
      .innerJoin(users, eq(users.id, teamMembers.userId));

    return members.map(m => ({ ...m.member, user: m.user }));
  }

  // Strategy methods
  async createStrategy(strategy: InsertStrategy & { createdById: number }): Promise<Strategy> {
    const [newStrategy] = await db
      .insert(strategies)
      .values({
        ...strategy,
        team_id: strategy.team_id,
      })
      .returning();
    return newStrategy;
  }

  async getStrategy(id: number): Promise<Strategy | undefined> {
    const [strategy] = await db
      .select()
      .from(strategies)
      .where(eq(strategies.id, id));
    return strategy;
  }

  async getTeamStrategies(teamId: number): Promise<Strategy[]> {
    return db
      .select()
      .from(strategies)
      .where(eq(strategies.team_id, teamId))
      .orderBy(desc(strategies.createdAt));
  }

  async getUserStrategies(userId: number): Promise<Strategy[]> {
    const userTeams = await this.getUserTeams(userId);
    const teamIds = userTeams.map(team => team.id);

    return db
      .select()
      .from(strategies)
      .where(inArray(strategies.team_id, teamIds))
      .orderBy(desc(strategies.createdAt));
  }

  // Event methods
  async createEvent(event: InsertEvent & { createdById: number }): Promise<Event> {
    const [newEvent] = await db
      .insert(events)
      .values(event)
      .returning();
    return newEvent;
  }

  async getTeamEvents(teamId: number): Promise<Event[]> {
    return db
      .select()
      .from(events)
      .where(eq(events.teamId, teamId))
      .orderBy(desc(events.startTime));
  }

  // Waitlist methods
  async addToWaitlist(entry: InsertWaitlist): Promise<Waitlist> {
    const [waitlistEntry] = await db
      .insert(waitlist)
      .values(entry)
      .returning();
    return waitlistEntry;
  }

  async isEmailRegistered(email: string): Promise<boolean> {
    const [entry] = await db
      .select()
      .from(waitlist)
      .where(eq(waitlist.email, email));
    return !!entry;
  }
}

export const storage = new DatabaseStorage();